Les fichiers textes sont encodés en UTF-8, avec un format Windows (fin de ligne en CR+LF)
